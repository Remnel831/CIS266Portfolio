
package team3_scrum4;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebResult;
import javax.jws.WebService;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.ws.Action;
import javax.xml.ws.RequestWrapper;
import javax.xml.ws.ResponseWrapper;

@WebService(name = "Team3_Piano_API", targetNamespace = "http://Team3_Scrum4/")
@XmlSeeAlso({
    ObjectFactory.class
})
public interface Team3PianoAPI {


    /**
     * 
     * @param price
     * @param model
     * @param manufacturer
     * @return
     *     returns team3_scrum4.Team3Piano
     */
    @WebMethod
    @WebResult(targetNamespace = "")
    @RequestWrapper(localName = "createPiano", targetNamespace = "http://Team3_Scrum4/", className = "team3_scrum4.CreatePiano")
    @ResponseWrapper(localName = "createPianoResponse", targetNamespace = "http://Team3_Scrum4/", className = "team3_scrum4.CreatePianoResponse")
    @Action(input = "http://Team3_Scrum4/Team3_Piano_API/createPianoRequest", output = "http://Team3_Scrum4/Team3_Piano_API/createPianoResponse")
    public Team3Piano createPiano(
        @WebParam(name = "model", targetNamespace = "")
        String model,
        @WebParam(name = "manufacturer", targetNamespace = "")
        String manufacturer,
        @WebParam(name = "price", targetNamespace = "")
        double price);

}

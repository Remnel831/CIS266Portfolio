package Team3_Scrum4;

public class Team3_Piano {
 
 private String model;
 private String manufacturer;
 private double price;
 
 public Team3_Piano()
 {
  setModel("");
  setManufacturer("");
  setPrice(0.0);
 }
 
 public Team3_Piano(String model, String manufacturer, double price)
 {
  this.model = model;
  this.manufacturer = manufacturer;
  this.price = price;
 }
 
 public String getModel() {
  return model;
 }
 public void setModel(String model) {
  this.model = model;
 }
 public String getManufacturer() {
  return manufacturer;
 }
 public void setManufacturer(String manufacturer) {
  this.manufacturer = manufacturer;
 }
 public double getPrice() {
  return price;
 }
 public void setPrice(double price) {
  this.price = price;
 }
}
 
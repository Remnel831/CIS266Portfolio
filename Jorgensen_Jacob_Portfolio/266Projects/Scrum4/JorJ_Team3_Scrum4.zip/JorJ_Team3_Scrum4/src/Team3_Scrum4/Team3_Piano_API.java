package Team3_Scrum4;

import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;

@WebService
public class Team3_Piano_API {
 
@WebMethod
 public Team3_Piano createPiano(
   @WebParam(name="model")String model,
   @WebParam(name="manufacturer")String manufacturer,
   @WebParam(name="price")double price)
 {
  return new Team3_Piano(model, manufacturer, price);
 }
}
 
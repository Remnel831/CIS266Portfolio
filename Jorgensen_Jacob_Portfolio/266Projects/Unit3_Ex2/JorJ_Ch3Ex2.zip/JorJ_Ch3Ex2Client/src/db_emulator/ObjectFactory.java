
package db_emulator;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the db_emulator package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _GetProductResponse_QNAME = new QName("http://db_emulator/", "getProductResponse");
    private final static QName _CreateProductDBObjectResponse_QNAME = new QName("http://db_emulator/", "createProductDB_ObjectResponse");
    private final static QName _GetProduct_QNAME = new QName("http://db_emulator/", "getProduct");
    private final static QName _CreateProductDBObject_QNAME = new QName("http://db_emulator/", "createProductDB_Object");
    private final static QName _GetProductObjectResponse_QNAME = new QName("http://db_emulator/", "getProductObjectResponse");
    private final static QName _GetProductObject_QNAME = new QName("http://db_emulator/", "getProductObject");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: db_emulator
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link GetProduct }
     * 
     */
    public GetProduct createGetProduct() {
        return new GetProduct();
    }

    /**
     * Create an instance of {@link GetProductResponse }
     * 
     */
    public GetProductResponse createGetProductResponse() {
        return new GetProductResponse();
    }

    /**
     * Create an instance of {@link GetProductObject }
     * 
     */
    public GetProductObject createGetProductObject() {
        return new GetProductObject();
    }

    /**
     * Create an instance of {@link GetProductObjectResponse }
     * 
     */
    public GetProductObjectResponse createGetProductObjectResponse() {
        return new GetProductObjectResponse();
    }

    /**
     * Create an instance of {@link CreateProductDBObject }
     * 
     */
    public CreateProductDBObject createCreateProductDBObject() {
        return new CreateProductDBObject();
    }

    /**
     * Create an instance of {@link CreateProductDBObjectResponse }
     * 
     */
    public CreateProductDBObjectResponse createCreateProductDBObjectResponse() {
        return new CreateProductDBObjectResponse();
    }

    /**
     * Create an instance of {@link Product }
     * 
     */
    public Product createProduct() {
        return new Product();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetProductResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://db_emulator/", name = "getProductResponse")
    public JAXBElement<GetProductResponse> createGetProductResponse(GetProductResponse value) {
        return new JAXBElement<GetProductResponse>(_GetProductResponse_QNAME, GetProductResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CreateProductDBObjectResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://db_emulator/", name = "createProductDB_ObjectResponse")
    public JAXBElement<CreateProductDBObjectResponse> createCreateProductDBObjectResponse(CreateProductDBObjectResponse value) {
        return new JAXBElement<CreateProductDBObjectResponse>(_CreateProductDBObjectResponse_QNAME, CreateProductDBObjectResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetProduct }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://db_emulator/", name = "getProduct")
    public JAXBElement<GetProduct> createGetProduct(GetProduct value) {
        return new JAXBElement<GetProduct>(_GetProduct_QNAME, GetProduct.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CreateProductDBObject }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://db_emulator/", name = "createProductDB_Object")
    public JAXBElement<CreateProductDBObject> createCreateProductDBObject(CreateProductDBObject value) {
        return new JAXBElement<CreateProductDBObject>(_CreateProductDBObject_QNAME, CreateProductDBObject.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetProductObjectResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://db_emulator/", name = "getProductObjectResponse")
    public JAXBElement<GetProductObjectResponse> createGetProductObjectResponse(GetProductObjectResponse value) {
        return new JAXBElement<GetProductObjectResponse>(_GetProductObjectResponse_QNAME, GetProductObjectResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetProductObject }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://db_emulator/", name = "getProductObject")
    public JAXBElement<GetProductObject> createGetProductObject(GetProductObject value) {
        return new JAXBElement<GetProductObject>(_GetProductObject_QNAME, GetProductObject.class, null, value);
    }

}

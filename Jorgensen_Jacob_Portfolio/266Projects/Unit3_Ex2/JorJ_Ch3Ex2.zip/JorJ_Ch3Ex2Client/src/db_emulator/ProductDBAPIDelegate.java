
package db_emulator;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebResult;
import javax.jws.WebService;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.ws.Action;
import javax.xml.ws.RequestWrapper;
import javax.xml.ws.ResponseWrapper;

@WebService(name = "ProductDB_APIDelegate", targetNamespace = "http://db_emulator/")
@XmlSeeAlso({
    ObjectFactory.class
})
public interface ProductDBAPIDelegate {


    /**
     * 
     * @param arg0
     * @return
     *     returns java.lang.String
     */
    @WebMethod
    @WebResult(targetNamespace = "")
    @RequestWrapper(localName = "getProduct", targetNamespace = "http://db_emulator/", className = "db_emulator.GetProduct")
    @ResponseWrapper(localName = "getProductResponse", targetNamespace = "http://db_emulator/", className = "db_emulator.GetProductResponse")
    @Action(input = "http://db_emulator/ProductDB_APIDelegate/getProductRequest", output = "http://db_emulator/ProductDB_APIDelegate/getProductResponse")
    public String getProduct(
        @WebParam(name = "arg0", targetNamespace = "")
        String arg0);

    /**
     * 
     * @param arg0
     * @return
     *     returns db_emulator.Product
     */
    @WebMethod
    @WebResult(targetNamespace = "")
    @RequestWrapper(localName = "getProductObject", targetNamespace = "http://db_emulator/", className = "db_emulator.GetProductObject")
    @ResponseWrapper(localName = "getProductObjectResponse", targetNamespace = "http://db_emulator/", className = "db_emulator.GetProductObjectResponse")
    @Action(input = "http://db_emulator/ProductDB_APIDelegate/getProductObjectRequest", output = "http://db_emulator/ProductDB_APIDelegate/getProductObjectResponse")
    public Product getProductObject(
        @WebParam(name = "arg0", targetNamespace = "")
        String arg0);

    /**
     * 
     * @return
     *     returns java.lang.String
     */
    @WebMethod(operationName = "createProductDB_Object")
    @WebResult(targetNamespace = "")
    @RequestWrapper(localName = "createProductDB_Object", targetNamespace = "http://db_emulator/", className = "db_emulator.CreateProductDBObject")
    @ResponseWrapper(localName = "createProductDB_ObjectResponse", targetNamespace = "http://db_emulator/", className = "db_emulator.CreateProductDBObjectResponse")
    @Action(input = "http://db_emulator/ProductDB_APIDelegate/createProductDB_ObjectRequest", output = "http://db_emulator/ProductDB_APIDelegate/createProductDB_ObjectResponse")
    public String createProductDBObject();

}

The newer version of the API created on March 17, 2019 
includes try/catches in the API methods & a new method which returns
a Product object in addition to a method which returns a String object.
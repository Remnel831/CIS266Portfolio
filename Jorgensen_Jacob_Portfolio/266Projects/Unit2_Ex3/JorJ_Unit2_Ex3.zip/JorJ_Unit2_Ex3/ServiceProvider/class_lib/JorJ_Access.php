<?php

class JorJ_Access
{
    private static $conn;
	private static $hostName = "localhost";
	private static $databaseName = "students";
	private static $userName = "root";
	private static $password = "";

    public function connectTo()
    {
		self::$conn = new mysqli(self::$hostName, self::$userName, self::$password, self::$databaseName );
		if (self::$conn->connect_error) {
			return("Connection Error to " . self::$hostName);
        }
		return("Connection successful to Host = " . self::$hostName . ", DB Name = " . self::$databaseName);
   				
	}
	
	public function showDatabases()
	{	self::connectTo();
		$query = "SHOW DATABASES";
		$result = mysqli_query (self::$conn, $query);
		self::$conn->close();
		return $result;
	}
	
	public function showTables()
	{	self::connectTo();
		$query = "SHOW TABLES FROM " . self::$databaseName;
		$result = mysqli_query (self::$conn, $query);
		self::$conn->close();
		return $result;
	}
	public function displayRecords($tableName)
	{   self::connectTo();
		$query = "SELECT * FROM " . $tableName;
		$result = mysqli_query (self::$conn, $query);
		self::$conn->close();
		return $result;
	}
	
	public function selectOne($idName, $id, $table)
	{
		self::connectTo();
		$query = "SELECT * 
				  FROM $table
				  WHERE $idName = $id";
		$result = mysqli_query(self::$conn, $query);

		if($result = self::$conn->query($query))
		{
			
		}
		self::$conn->close();
		return $result;
	}
}

?>
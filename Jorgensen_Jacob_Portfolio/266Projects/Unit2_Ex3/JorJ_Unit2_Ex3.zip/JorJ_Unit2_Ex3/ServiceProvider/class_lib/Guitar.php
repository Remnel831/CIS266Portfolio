<?php




class Guitar{
    private $guitarID;
    private $guitarMake;
    private $guitarModel;
    private $guitarPrice;


    public function __construct(){
        $this->guitarID = 0;
        $this->guitarMake = "";
        $this->guitarModel = "";
        $this->guitarPrice = 0;
    }

    public function setID($idIn){
        $this->guitarID = $idIn;
    }
    public function setMake($makeIn){
        $this->guitarMake = $makeIn;
    }
    public function setModel($modelIn){
        $this->guitarModel = $modelIn;
    }
    public function setPrice($priceIn){
        $this->guitarPrice = $priceIn;
    }

    public function getID(){
        return $this->guitarID;
    }
    public function getMake(){
        return $this->guitarMake;
    }
    public function getModel(){
        return $this->guitarModel;
    }
    public function getPrice(){
        return $this->guitarPrice;
    }

    public function toString(){

        $stringOut = "Guitar ID:" . $this->guitarID . "</br>" .
                     "Guitar Make:" . $this->guitarMake . "</br>" .
                     "Guitar Model:" . $this->guitarModel . "</br>" .
                     "Guitar Price:" . $this->guitarPrice . "</br>";
        return $stringOut;
    }
    public function toArray(){
        return[
            "GuitarID" => $this->guitarID,
            "GuitarMake" => $this->guitarMake,
            "GuitarModel" => $this->guitarModel,
            "GuitarPrice" => $this->guitarPrice
        ];
    }
}
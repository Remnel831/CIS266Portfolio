<?php
include('class_lib/JorJ_Access.php');

$DB_Access = new JorJ_Access(); 

$DB_Result = $DB_Access->showTables();
$rValue = "";
		while($row = $DB_Result->fetch_assoc())
		{ 
			foreach($row as $value)
			{
				$rValue = $rValue . "$value ";
			}
		}
$data = array();
$data['tablesList'] = $rValue;

print(json_encode($data));



?>

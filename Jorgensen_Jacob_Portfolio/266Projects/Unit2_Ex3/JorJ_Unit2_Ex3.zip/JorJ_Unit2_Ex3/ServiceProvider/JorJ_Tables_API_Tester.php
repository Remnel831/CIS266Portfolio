<?php
include('class_lib/JorJ_Access.php');

#Printing out the does seem cleaner than putting this php into the middle of a normal html page.
print("<h2>");

$DB_Access = new JorJ_Access(); 

print("<hr />");
$DB_Result = $DB_Access->showTables(); 
$rValue = "List of Tables in LocalHost: ";
		while($row = $DB_Result->fetch_assoc())
		{ 
			foreach($row as $value)
			{
				$rValue = " " . $rValue . " $value";
			}
		}
		
$data = array();
$data['tablelist'] = $rValue; 

print(json_encode($data));


print("</h2>");
 

?>

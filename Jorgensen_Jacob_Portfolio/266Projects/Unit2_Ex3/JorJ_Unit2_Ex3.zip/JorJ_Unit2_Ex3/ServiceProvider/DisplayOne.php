<?php
include('class_lib/JorJ_Access.php');
$DB_Access = new JorJ_Access(); 
if(!empty($_POST))
{
    $table = "jorj_unit2table";
    $id = $_POST['id'];
    $idName = 'student_id';
    try
    {

        $DB_Result = $DB_Access->selectOne($idName, $id, $table);
        $rValue = "";
        while($row = $DB_Result->fetch_assoc())
        { 
            echo "<table>
                    <th>ID</th>
                   <th>Name</th>
                   <th>Major</th>";
            foreach($row as $value)
            {
                $rValue = "<tr><td>" . $rValue . "$value " . "</td></tr>"; 
            }
            echo"</table>";
        }
        echo($rValue);
        if(empty($rValue)){
            echo("Nothing found while searching for " .$idName . " " . $id);
        }
    }
    catch(Throwable $e)
    {
        #I could've only allowed the query to go through if the ID was an int, but I built it thinking eventually the table name and ID Name would
        #be something the user could set.  So you'd be able to search for an ID like "A2324" or something.
        echo("An error occurred while searching for " . $id);
    }
}
?>
<?php
include('class_lib/JorJ_Access.php');

$DB_Access = new JorJ_Access(); 

$table = $_REQUEST['tableName'];

$DB_Result = $DB_Access->displayRecords($table);

$data = array(); 
if($DB_Result){
  $index = 0;
  while($row = $DB_Result->fetch_assoc())
  { $rValue = "";
    foreach($row as $value)
        {$rValue = $rValue . "$value ";}
    $data[] = $rValue;
  }
  
  print(json_encode($data));
  
}
else{
  print("error searching for: " . $table);
}

?>

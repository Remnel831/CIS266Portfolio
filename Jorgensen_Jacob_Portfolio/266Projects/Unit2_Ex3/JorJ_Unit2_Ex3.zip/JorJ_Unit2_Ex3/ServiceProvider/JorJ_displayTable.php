<?php

$hostName = "localhost";
$userName = "root";
$password = "";
$databaseName = "students";
$tableName = "jorj_unit2table";


$mysqli = new mysqli($hostName, $userName, $password, $databaseName);

if($mysqli->connect_error)
{
die("Connection Error to $hostName: " . $mysqli->connect_error);
}


$query = "SHOW DATABASES";

$result = $mysqli->query($query);

if(!$result)
{
    die('There was an error running: '. $query);
}
while($row = $result->fetch_assoc())
{
    print_r($row);
    print("<br>");
}

print("<hr/>");


$query = 'SELECT * FROM ' . $tableName;

if(!$result = $mysqli->query($query))
{
    die('There was an error running '. $query);
}

While($row =$result->fetch_assoc())
{
    print("Student ID: " . $row["student_id"]. " " . "Student Name: " . $row["student_name"] . " ". "Student Major: " . $row["student_major"]."</br>");
}

$mysqli->close();

?>
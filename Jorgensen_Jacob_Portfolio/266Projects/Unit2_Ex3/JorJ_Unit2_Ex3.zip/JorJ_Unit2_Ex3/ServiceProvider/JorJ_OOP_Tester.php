<?php
include('class_lib/JorJ_Access.php');


echo("<h3>");

$DB_Access = new JorJ_Access(); 


echo("<hr />");
$DB_Result = $DB_Access->showDatabases( );
$rValue = "List of Databases in MySQL: <br />";
		while($row = $DB_Result->fetch_assoc())
		{ 
			foreach($row as $value)
			{
				$rValue = $rValue . "$value <br />";
			}
		}
echo($rValue);


echo("<hr />");
$DB_Result = $DB_Access->showTables();
$rValue = "List of Tables in MyPHP: <br />";
		while($row = $DB_Result->fetch_assoc())
		{ 
			foreach($row as $value)
			{
				$rValue = $rValue . "$value <br />";
			}
		}
echo($rValue);


echo("<hr />");
$table = "jorj_unit2table";
$DB_Result = $DB_Access->displayRecords($table);
$rValue = "List of Records from " . $table . " table<br />";
		while($row = $DB_Result->fetch_assoc())
		{ 
			foreach($row as $value)
			{
				$rValue = $rValue . "$value "; 
			}
			$rValue = $rValue . "<br />";
		}
echo($rValue);

echo("</h3>");

	$table = "jorj_unit2table";
	$id = 2;
	$idName = 'student_id';
	$rValue = "Results of selectOne: ";
	$DB_Result = $DB_Access->selectOne($idName, $id, $table);
	echo("<h2>select one</h2>");
	while($row = $DB_Result->fetch_assoc())
	{ 
		foreach($row as $value)
		{
			$rValue = $rValue . "$value "; 
		}
	}
	echo($rValue);


?>

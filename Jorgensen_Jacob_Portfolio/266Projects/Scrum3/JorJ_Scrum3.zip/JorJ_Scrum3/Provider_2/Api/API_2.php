<?php
/*
 * Author: Jacob Jorgensen
 * Class: CIS266
 * Project: Scrum 3 – Team 2
 * Date: March 26, 2025
 * 
 * This is the API for the SCRUM 3 bookstore project. It allows the frontend to interact with the DB.
 */

require('../Classes/DB.php');
include('../Classes/Author.php');
include('../Classes/Book.php');
include('../Classes/Customer.php');

class API_2
{
    public function SearchItem($type) {
        $db = new DB();

        switch ($type) {
            case 'Author':
                $authorOutput = $db->getAuthorById($_POST['authorID']);
                echo json_encode($authorOutput);
                return;
            case 'Book':
                $bookOutput = $db->getBookById($_POST['bookID']);
                echo json_encode($bookOutput);
                return;
            case 'Customer':
                $customerOutput = $db->getCustomerById($_POST['customerID']);
                echo json_encode($customerOutput);
                return;
        }
    }

    public function InsertItem($type) {
        $db = new DB();

        switch ($type) {
            case 'Author':
                $result = $db->createAuthor($_POST['authorName'], $_POST['authorBio'], $_POST['authorBirthYear'], $_POST['authorCountry']);
                echo json_encode(["success" => $result]);
                break;
            case 'Book':
                $result = $db->createBook($_POST['bookTitle'], $_POST['authorID'], $_POST['bookPrice'], $_POST['bookStockQuantity']);
                echo json_encode(["success" => $result]);
                break;
            case 'Customer':
                $result = $db->createCustomer($_POST['customerName'], $_POST['customerEmail'], $_POST['customerPhone'], $_POST['customerJoinedDate']);
                echo json_encode(["success" => $result]);
                break;
        }
    }

    public function UpdateItem($type) {
        $db = new DB();
        switch ($type) {
            case 'Author':
                $result = $db->updateAuthor($_POST['authorID'], $_POST['authorName'], $_POST['authorBio'], $_POST['authorBirthYear'], $_POST['authorCountry']);
                echo json_encode(["success" => $result]);
                break;
            case 'Book':
                $result = $db->updateBook($_POST['bookID'], $_POST['bookTitle'], $_POST['authorID'], $_POST['bookPrice'], $_POST['bookStockQuantity']);
                echo json_encode(["success" => $result]);
                break;
            case 'Customer':
                $result = $db->updateCustomer($_POST['customerID'], $_POST['customerName'], $_POST['customerEmail'], $_POST['customerPhone'], $_POST['customerJoinedDate']);
                echo json_encode(["success" => $result]);
                break;
        }
    }

    public function DeleteItem($type) {
        $db = new DB();

        switch ($type) {
            case 'Author':
                $result = $db->deleteAuthor($_POST['authorID']);
                echo json_encode(["success" => $result]);
                break;
            case 'Book':
                $result = $db->deleteBook($_POST['bookID']);
                echo json_encode(["success" => $result]);
                break;
            case 'Customer':
                $result = $db->deleteCustomer($_POST['customerID']);
                echo json_encode(["success" => $result]);
                break;
        }
    }

    public function OnLoad() {
        if (isset($_POST['Request'])) {
            $request = $_POST['Request'];
            $type = $_POST['Type'];

            switch ($request) {
                case 'Search':
                    $this->SearchItem($type);
                    break;
                case 'Insert':
                    $this->InsertItem($type);
                    break;
                case 'Update':
                    $this->UpdateItem($type);
                    break;
                case 'Delete':
                    $this->DeleteItem($type);
                    break;
            }
        }
    }
}

$api = new API_2();
$api->OnLoad();
?>
<?php
// Include the necessary files and initialize the API object
include_once '../Api/API_2.php'; 
$api = new API_2();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    
    // Get the action to be performed based on the button clicked
    $action = $_POST['action'];
    header('Content-Type: application/json'); 

    switch ($action) {
        case 'Search Author':
            // Sending POST data for searching an Author
            $_POST['authorID'] = '1';  // Example search query
            $api->SearchItem('Author');  // Call the search API for Author
            break;
        case 'Insert Author':
            // Sending POST data for inserting an Author
            $_POST['authorName'] = 'John Test';
            $_POST['authorBio'] = 'Test bio';
            $_POST['authorBirthYear'] = 1970;
            $_POST['authorCountry'] = 'Testland';
            $api->InsertItem('Author');  // Call the insert API for Author
            break;
        case 'Update Author':
            // Sending POST data for updating an Author
            $_POST['authorID'] = 8;  // Example authorID
            $_POST['authorName'] = 'Updated Author';
            $_POST['authorBio'] = 'Updated bio';
            $_POST['authorBirthYear'] = 1975;
            $_POST['authorCountry'] = 'Updatedland';
            $api->UpdateItem('Author');  // Call the update API for Author
            break;
        case 'Delete Author':
            // Sending POST data for deleting an Author
            $_POST['authorID'] = 8;  // Example authorID to delete
            $api->DeleteItem('Author');  // Call the delete API for Author
            break;
    }
    exit; // End the script after the action
}

?>

<!-- HTML Form with buttons to trigger each action -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Test API</title>
</head>
<body>
    <h1>Test API Operations</h1>

    <!-- Buttons for each operation -->
    <form method="POST" action="">
        <button type="submit" name="action" value="Search Author">Search Author</button>
        <button type="submit" name="action" value="Insert Author">Insert Author</button>
        <button type="submit" name="action" value="Update Author">Update Author</button>
        <button type="submit" name="action" value="Delete Author">Delete Author</button>
</body>
</html>

<?php
require_once('../Api/API_2.php');
require_once('../Classes/DB.php');

$db = new DB();
$authors = $db->getAllAuthors() ?? [];
$books = $db->getAllBooks() ?? [];
$customers = $db->getAllCustomers() ?? [];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>All Records</title>
</head>
<body>
    <h1>Bookstore Database Records</h1>
    
    <hr />
    <h2>Authors</h2>
    <?php
    if (!empty($authors)) {
        foreach ($authors as $author) {
            echo "Author ID: " . ($author['author_id'] ?? 'N/A') . 
                 " | Name: " . ($author['name'] ?? 'N/A') . 
                 " | Bio: " . ($author['bio'] ?? 'N/A') . 
                 " | Birth Year: " . ($author['birth_year'] ?? 'N/A') . 
                 " | Country: " . ($author['country'] ?? 'N/A') . "<br>";
        }
    } else {
        echo "No authors found.<br>";
    }
    ?>

    <hr />
    <h2>Books</h2>
    <?php
    if (!empty($books)) {
        foreach ($books as $book) {
            echo "Book ID: " . ($book['book_id'] ?? 'N/A') . 
                 " | Title: " . ($book['title'] ?? 'N/A') . 
                 " | Author ID: " . ($book['author_id'] ?? 'N/A') . 
                 " | Price: $" . ($book['price'] ?? 'N/A') . 
                 " | Stock: " . ($book['stock_quantity'] ?? 'N/A') . "<br>";
        }
    } else {
        echo "No books found.<br>";
    }
    ?>

    <hr />
    <h2>Customers</h2>
    <?php
    if (!empty($customers)) {
        foreach ($customers as $customer) {
            echo "Customer ID: " . ($customer['customer_id'] ?? 'N/A') . 
                 " | Name: " . ($customer['name'] ?? 'N/A') . 
                 " | Email: " . ($customer['email'] ?? 'N/A') . 
                 " | Phone: " . ($customer['phone'] ?? 'N/A') . 
                 " | Joined: " . ($customer['joined_date'] ?? 'N/A') . "<br>";
        }
    } else {
        echo "No customers found.<br>";
    }
    ?>
    
</body>
</html>

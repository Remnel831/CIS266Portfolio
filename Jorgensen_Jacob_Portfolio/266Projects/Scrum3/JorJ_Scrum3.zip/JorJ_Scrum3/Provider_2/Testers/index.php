<?php
require('../Api/API_2.php');

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bookstore API Tester</title>
</head>
<body>
    <h1>Bookstore API Tester</h1>
    <ul>
        <li><a href="display_records.php">View All Records</a></li>
        <li><a href="test_api.php">Test API Functions</a></li>
    </ul>
</body>
</html>

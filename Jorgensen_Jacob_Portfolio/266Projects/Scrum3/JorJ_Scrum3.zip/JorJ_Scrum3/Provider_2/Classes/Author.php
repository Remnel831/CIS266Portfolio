<?php
/*
 * Author: Jason Nelson
 * Class: CIS266
 * Project: Scrum 3 – Team 2
 * Date: March 26, 2025
 * 
 * Description:
 * This class represents an Author object in the Bookstore project.
 * It contains private properties related to an author and provides
 * getter/setter methods for each. It also includes a custom toString()
 * method for easy display and a toArray() method for JSON serialization.
 */

class Author {
    // Instance Variables - represent columns in the authors table
    private $authorID;
    private $authorName;
    private $authorBio;
    private $authorBirthYear;
    private $authorCountry;

    // Constructor - initializes default values
    public function __construct() 
    {
        $this->authorID = 0;
        $this->authorName = "";
        $this->authorBio = "";
        $this->authorBirthYear = 0;
        $this->authorCountry = "";
    }

    // Mutator Methods (Setters)
    public function setAuthorID($authorID) 
    {
        $this->authorID = $authorID;
    }

    public function setAuthorName($authorName) 
    {
        $this->authorName = $authorName;
    }

    public function setAuthorBio($authorBio) 
    {
        $this->authorBio = $authorBio;
    }

    public function setAuthorBirthYear($authorBirthYear) 
    {
        $this->authorBirthYear = $authorBirthYear;
    }

    public function setAuthorCountry($authorCountry) 
    {
        $this->authorCountry = $authorCountry;
    }

    // Accessor Methods (Getters)
    public function getAuthorID() 
    {
        return $this->authorID;
    }

    public function getAuthorName() 
    {
        return $this->authorName;
    }

    public function getAuthorBio() 
    {
        return $this->authorBio;
    }

    public function getAuthorBirthYear() 
    {
        return $this->authorBirthYear;
    }

    public function getAuthorCountry() 
    {
        return $this->authorCountry;
    }

    // Returns author details as an HTML-formatted string (for tester display/debugging)
    public function toString()
    {
        $rString = "Author ID: " . $this->authorID . "<br />" . 
                   "Author Name: " . $this->authorName . "<br />" . 
                   "Author Bio: " . $this->authorBio . "<br />" . 
                   "Author Birth Year: " . $this->authorBirthYear . "<br />" . 
                   "Author Country: " . $this->authorCountry . "<br />";
        return $rString;
    }

    // Converts the author object into an associative array (useful for JSON responses)
    public function toArray()
    {
        return [
            "authorID" => $this->authorID,
            "authorName" => $this->authorName,
            "authorBio" => $this->authorBio,
            "authorBirthYear" => $this->authorBirthYear,
            "authorCountry" => $this->authorCountry
        ];
    }
}
?>

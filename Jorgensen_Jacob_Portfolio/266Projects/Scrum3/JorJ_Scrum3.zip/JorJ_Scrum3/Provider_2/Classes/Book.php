<?php
/*
 * Author: Jason Nelson
 * Class: CIS266
 * Project: Scrum 3 – Team 2
 * Date: March 26, 2025
 * 
 * Description:
 * This class represents a Book object in the Bookstore project.
 * It includes properties for ID, title, price, stock, and a reference
 * to the author. The class provides getter/setter methods, a display method,
 * and a helper method for JSON output.
 */

class Book {
    // Instance Variables - match the columns from the books table
    private $bookID;
    private $bookTitle;
    private $authorID;
    private $bookPrice;
    private $bookStockQuantity;

    // Constructor - initializes properties with default values
    public function __construct() 
    {
        $this->bookID = 0;
        $this->bookTitle = "";
        $this->authorID = 0;
        $this->bookPrice = 0.0;
        $this->bookStockQuantity = 0;
    }

    // Mutator Methods (Setters)
    public function setBookID($bookID) 
    {
        $this->bookID = $bookID;
    }

    public function setBookTitle($bookTitle) 
    {
        $this->bookTitle = $bookTitle;
    }

    public function setAuthorID($authorID) 
    {
        $this->authorID = $authorID;
    }

    public function setBookPrice($bookPrice) 
    {
        $this->bookPrice = $bookPrice;
    }

    public function setBookStockQuantity($bookStockQuantity) 
    {
        $this->bookStockQuantity = $bookStockQuantity;
    }

    // Accessor Methods (Getters)
    public function getBookID() 
    {
        return $this->bookID;
    }

    public function getBookTitle() 
    {
        return $this->bookTitle;
    }

    public function getAuthorID() 
    {
        return $this->authorID;
    }

    public function getBookPrice() 
    {
        return $this->bookPrice;
    }

    public function getBookStockQuantity() 
    {
        return $this->bookStockQuantity;
    }

    // Returns book details as a formatted string (for debugging or display)
    public function toString()
    {
        $rString = "Book ID: " . $this->bookID . "<br>" . 
                   "Book Title: " . $this->bookTitle . "<br>" . 
                   "Author ID: " . $this->authorID . "<br>" . 
                   "Book Price: " . $this->bookPrice . "<br>" . 
                   "Book Stock Quantity: " . $this->bookStockQuantity . "<br>";
        return $rString;
    }

    // Converts the book object into an associative array (for JSON responses)
    public function toArray()
    {
        return [
            "bookID" => $this->bookID,
            "bookTitle" => $this->bookTitle,
            "authorID" => $this->authorID,
            "bookPrice" => $this->bookPrice,
            "bookStockQuantity" => $this->bookStockQuantity
        ];
    }
}
?>

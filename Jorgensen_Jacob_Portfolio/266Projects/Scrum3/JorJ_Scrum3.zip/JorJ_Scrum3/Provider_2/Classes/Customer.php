<?php
/*
 * Author: Jason Nelson
 * Class: CIS266
 * Project: Scrum 3 – Team 2
 * Date: March 26, 2025
 * 
 * Description:
 * This class represents a Customer object in the Bookstore project.
 * It stores customer-specific data like name, email, phone, and join date.
 * Standard getter/setter methods are included along with a formatted string 
 * method and a toArray method for use with JSON or API output.
 */

class Customer {
    // Instance Variables - correspond to columns in the customers table
    private $customerID;
    private $customerName;
    private $customerEmail;
    private $customerPhone;
    private $customerJoinedDate;

    // Constructor - initializes default values
    public function __construct() 
    {
        $this->customerID = 0;
        $this->customerName = "";
        $this->customerEmail = "";
        $this->customerPhone = "";
        $this->customerJoinedDate = null;
    }

    // Mutator Methods (Setters)
    public function setCustomerID($customerID) 
    {
        $this->customerID = $customerID;
    }

    public function setCustomerName($customerName) 
    {
        $this->customerName = $customerName;
    }

    public function setCustomerEmail($customerEmail) 
    {
        $this->customerEmail = $customerEmail;
    }

    public function setCustomerPhone($customerPhone) 
    {
        $this->customerPhone = $customerPhone;
    }

    public function setCustomerJoinedDate($customerJoinedDate) 
    {
        $this->customerJoinedDate = $customerJoinedDate;
    }

    // Accessor Methods (Getters)
    public function getCustomerID() 
    {
        return $this->customerID;
    }

    public function getCustomerName() 
    {
        return $this->customerName;
    }

    public function getCustomerEmail() 
    {
        return $this->customerEmail;
    }

    public function getCustomerPhone() 
    {
        return $this->customerPhone;
    }

    public function getCustomerJoinedDate() 
    {
        return $this->customerJoinedDate;
    }

    // Returns customer details as a formatted string (useful for display/testing)
    public function toString()
    {
        $rString = "Customer ID: " . $this->customerID . "<br>" . 
                   "Customer Name: " . $this->customerName . "<br>" . 
                   "Customer Email: " . $this->customerEmail . "<br>" . 
                   "Customer Phone: " . $this->customerPhone . "<br>" . 
                   "Customer Joined Date: " . $this->customerJoinedDate . "<br>";
        return $rString;
    }

    // Converts customer data to an array (used in JSON/API output)
    public function toArray()
    {
        return [
            "customerID" => $this->customerID,
            "customerName" => $this->customerName,
            "customerEmail" => $this->customerEmail,
            "customerPhone" => $this->customerPhone,
            "customerJoinedDate" => $this->customerJoinedDate
        ];
    }
}
?>

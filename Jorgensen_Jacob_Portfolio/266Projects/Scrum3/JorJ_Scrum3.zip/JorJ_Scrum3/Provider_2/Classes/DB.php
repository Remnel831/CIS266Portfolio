<?php
/*
 * Author: Jason Nelson
 * Class: CIS266
 * Project: Scrum 3 – Team 2
 * Date: March 26, 2025
 * 
 * Description:
 * This class handles all database operations (CRUD) for the Bookstore web service.
 * It connects to a MySQL database and provides methods to interact with the
 * authors, books, and customers tables. This is the core "business logic" of the
 * application, and is used by the API to communicate between the frontend and database.
 */

class DB {
    // Static properties for DB credentials and connection
    private static $conn;
	private static $hostName = "localhost";
	private static $databaseName = "bookstore";
	private static $userName = "root";
	private static $password = "";

    // Establish connection to the database
    public function connectTo()
    {
        self::$conn = new mysqli(self::$hostName, self::$userName, self::$password, self::$databaseName);
        if (self::$conn->connect_error) {
            die("Connection Error to " . self::$hostName . ": " . self::$conn->connect_error);
        }
        return("Connection successful to hostName = " . self::$hostName . " and databaseName = " . self::$databaseName);
    }

    // --------------------
    // CREATE Operations
    // --------------------

    // Insert a new author into the authors table
    public function createAuthor($authorName, $authorBio, $authorBirthYear, $authorCountry)
    {
        self::connectTo();
        $query = "INSERT INTO authors (name, bio, birth_year, country) VALUES (?, ?, ?, ?)";
        $stmt = self::$conn->prepare($query);
        $stmt->bind_param("ssis", $authorName, $authorBio, $authorBirthYear, $authorCountry);
        $result = $stmt->execute();
        self::$conn->close();
        return $result;
    }

    // Insert a new book into the books table
    public function createBook($bookTitle, $authorId, $bookPrice, $bookStockQuantity)
    {
        self::connectTo();
        $query = "INSERT INTO books (title, author_id, price, stock_quantity) VALUES (?, ?, ?, ?)";
        $stmt = self::$conn->prepare($query);
        $stmt->bind_param("sidi", $bookTitle, $authorId, $bookPrice, $bookStockQuantity);
        $result = $stmt->execute();
        self::$conn->close();
        return $result;
    }

    // Insert a new customer into the customers table
    public function createCustomer($customerName, $customerEmail, $customerPhone, $customerJoinedDate)
    {
        self::connectTo();
        $query = "INSERT INTO customers (name, email, phone, joined_date) VALUES (?, ?, ?, ?)";
        $stmt = self::$conn->prepare($query);
        $stmt->bind_param("ssss", $customerName, $customerEmail, $customerPhone, $customerJoinedDate);
        $result = $stmt->execute();
        self::$conn->close();
        return $result;
    }

    // --------------------
    // READ Operations
    // --------------------

    // Get all authors
    public function getAllAuthors() {
        self::connectTo();
        $query = "SELECT * FROM authors";
        $result = mysqli_query(self::$conn, $query);
    
        $authors = [];
        while ($row = mysqli_fetch_assoc($result)) {
            $authors[] = $row;
        }
    
        self::$conn->close();
        return $authors;
    }

    // Get a single author by ID
    public function getAuthorById($authorId) {
        self::connectTo();
        $query = "SELECT * FROM authors WHERE author_id = ?";
        $stmt = self::$conn->prepare($query);
        $stmt->bind_param("i", $authorId);
        $stmt->execute();
        $result = $stmt->get_result();
        $author = $result->fetch_assoc();
        self::$conn->close();
        if (!$author) {
            return ["error" => "No record found with ID: $authorId"];
        }
        return $author;
    }

    // Get all books
    public function getAllBooks() {
        self::connectTo();
        $query = "SELECT * FROM books";
        $result = mysqli_query(self::$conn, $query);
    
        $books = [];
        while ($row = mysqli_fetch_assoc($result)) {
            $books[] = $row;
        }
    
        self::$conn->close();
        return $books;
    }

    // Get a single book by ID
    public function getBookById($bookId) {
        self::connectTo();
        $query = "SELECT * FROM books WHERE book_id = ?";
        $stmt = self::$conn->prepare($query);
        $stmt->bind_param("i", $bookId);
        $stmt->execute();
        $result = $stmt->get_result();
        $book = $result->fetch_assoc();
        self::$conn->close();
        if (!$book) {
            return ["error" => "No record found with ID: $bookId"];
        }
        return $book;
    }

    // Get all customers
    public function getAllCustomers() {
        self::connectTo();
        $query = "SELECT * FROM customers";
        $result = mysqli_query(self::$conn, $query);
    
        $customers = [];
        while ($row = mysqli_fetch_assoc($result)) {
            $customers[] = $row;
        }
    
        self::$conn->close();
        return $customers;
    }

    // Get a single customer by ID
    public function getCustomerById($customerId)
    {
        self::connectTo();
        $query = "SELECT * FROM customers WHERE customer_id = ?";
        $stmt = self::$conn->prepare($query);
        $stmt->bind_param("i", $customerId);
        $stmt->execute();
        $result = $stmt->get_result();
        $customer = $result->fetch_assoc();
        self::$conn->close();
        if (!$customer) {
            return ["error" => "No record found with ID: $customerId"];
        }
        return $customer;
    }

    // --------------------
    // UPDATE Operations
    // --------------------

    public function updateAuthor($authorId, $authorName, $authorBio, $authorBirthYear, $authorCountry)
    {
        self::connectTo();
        $query = "UPDATE authors SET name = ?, bio = ?, birth_year = ?, country = ? WHERE author_id = ?";
        $stmt = self::$conn->prepare($query);
        $stmt->bind_param("ssisi", $authorName, $authorBio, $authorBirthYear, $authorCountry, $authorId);
        $result = $stmt->execute();
        self::$conn->close();
        return $result;
    }

    public function updateBook($bookId, $bookTitle, $authorId, $bookPrice, $bookStockQuantity)
    {
        self::connectTo();
        $query = "UPDATE books SET title = ?, author_id = ?, price = ?, stock_quantity = ? WHERE book_id = ?";
        $stmt = self::$conn->prepare($query);
        $stmt->bind_param("sidii", $bookTitle, $authorId, $bookPrice, $bookStockQuantity, $bookId);
        $result = $stmt->execute();
        self::$conn->close();
        return $result;
    }

    public function updateCustomer($customerId, $customerName, $customerEmail, $customerPhone, $customerJoinedDate)
    {
        self::connectTo();
        $query = "UPDATE customers SET name = ?, email = ?, phone = ?, joined_date = ? WHERE customer_id = ?";
        $stmt = self::$conn->prepare($query);
        $stmt->bind_param("ssssi", $customerName, $customerEmail, $customerPhone, $customerJoinedDate, $customerId);
        $result = $stmt->execute();
        self::$conn->close();
        return $result;
    }

    // --------------------
    // DELETE Operations
    // --------------------

    public function deleteAuthor($authorId)
    {
        self::connectTo();
        $query = "DELETE FROM authors WHERE author_id = ?";
        $stmt = self::$conn->prepare($query);
        $stmt->bind_param("i", $authorId);
        $result = $stmt->execute();
        self::$conn->close();
        return $result;
    }

    public function deleteBook($bookId)
    {
        self::connectTo();
        $query = "DELETE FROM books WHERE book_id = ?";
        $stmt = self::$conn->prepare($query);
        $stmt->bind_param("i", $bookId);
        $result = $stmt->execute();
        self::$conn->close();
        return $result;
    }

    public function deleteCustomer($customerId)
    {
        self::connectTo();
        $query = "DELETE FROM customers WHERE customer_id = ?";
        $stmt = self::$conn->prepare($query);
        $stmt->bind_param("i", $customerId);
        $result = $stmt->execute();
        self::$conn->close();
        return $result;
    }
}
?>

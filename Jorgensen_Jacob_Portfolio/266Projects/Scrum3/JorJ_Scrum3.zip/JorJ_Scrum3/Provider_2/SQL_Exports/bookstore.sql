-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Mar 26, 2025 at 12:35 AM
-- Server version: 9.1.0
-- PHP Version: 8.3.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bookstore`
--

CREATE DATABASE IF NOT EXISTS `bookstore`;
USE `bookstore`;

-- --------------------------------------------------------

--
-- Table structure for table `authors`
--

DROP TABLE IF EXISTS `authors`;
CREATE TABLE IF NOT EXISTS `authors` (
  `author_id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `bio` text NOT NULL,
  `birth_year` int NOT NULL,
  `country` varchar(50) NOT NULL,
  PRIMARY KEY (`author_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

--
-- Dumping data for table `authors`
--

INSERT INTO `authors` (`author_id`, `name`, `bio`, `birth_year`, `country`) VALUES
(1, 'J.K. Rowling', 'Author of the Harry Potter series.', 1965, 'UK'),
(2, 'George R.R. Martin', 'Author of A Song of Ice and Fire.', 1948, 'USA'),
(3, 'J.R.R. Tolkien', 'Author of The Lord of the Rings.', 1892, 'UK'),
(4, 'Stephen King', 'Author of horror and suspense novels.', 1947, 'USA'),
(5, 'Agatha Christie', 'Famous mystery writer.', 1890, 'UK'),
(6, 'Dan Brown', 'Author of The Da Vinci Code.', 1964, 'USA'),
(7, 'Suzanne Collins', 'Author of The Hunger Games.', 1962, 'USA');

-- --------------------------------------------------------

--
-- Table structure for table `books`
--

DROP TABLE IF EXISTS `books`;
CREATE TABLE IF NOT EXISTS `books` (
  `book_id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(150) NOT NULL,
  `author_id` int NOT NULL,
  `price` decimal(6,2) NOT NULL,
  `stock_quantity` int NOT NULL,
  PRIMARY KEY (`book_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

--
-- Dumping data for table `books`
--

INSERT INTO `books` (`book_id`, `title`, `author_id`, `price`, `stock_quantity`) VALUES
(1, 'Harry Potter and the Sorcerer\'s Stone', 1, 10.99, 50),
(2, 'A Game of Thrones', 2, 12.99, 40),
(3, 'The Fellowship of the Ring', 3, 11.50, 35),
(4, 'The Shining', 4, 9.75, 20),
(5, 'Murder on the Orient Express', 5, 8.99, 30),
(6, 'The Da Vinci Code', 6, 13.50, 25),
(7, 'The Hunger Games', 7, 10.00, 60);

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

DROP TABLE IF EXISTS `customers`;
CREATE TABLE IF NOT EXISTS `customers` (
  `customer_id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `joined_date` date NOT NULL,
  PRIMARY KEY (`customer_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`customer_id`, `name`, `email`, `phone`, `joined_date`) VALUES
(1, 'Alice Johnson', 'alice@example.com', '555-1234', '2023-01-10'),
(2, 'Bob Smith', 'bob@example.com', '555-5678', '2023-03-15'),
(3, 'Cathy Brown', 'cathy@example.com', '555-8765', '2023-05-01'),
(4, 'David Wilson', 'david@example.com', '555-2345', '2023-07-12'),
(5, 'Ella Thompson', 'ella@example.com', '555-3456', '2023-08-20'),
(6, 'Frank Garcia', 'frank@example.com', '555-4567', '2023-10-05'),
(7, 'Grace Lee', 'grace@example.com', '555-6789', '2024-02-17');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

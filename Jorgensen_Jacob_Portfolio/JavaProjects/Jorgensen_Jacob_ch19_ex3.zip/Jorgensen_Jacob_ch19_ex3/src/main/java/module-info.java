module jorgensen.ch19_ex3 {
    requires javafx.controls;
	requires javafx.graphics;
	requires java.sql;
    exports jorgensen.ch19_ex3;
}

package jorgensen.ch19_ex3;
/*Jacob Jorgensen
 * 12/1/2024
 * This is the main app for the product manager
 */
import java.util.ArrayList;
import java.util.Optional;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.TextInputDialog;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.stage.Stage;



public class ProductManagerApp extends Application {

	
	private TextField codeField;
	private TextField descriptionField;
	private TextField priceField;
	private TextArea outputArea;
	
	private Button addButton;
	private Button updateButton;
	private Button deleteButton;
	private Button exitButton;
	Validation v = new Validation();
 	private Stage updateScreen = new Stage();

 	private TextField updateCodeField = new TextField();
 	private TextField updateDescField = new TextField();
 	private TextField updatePriceField = new TextField();
    Label updateCodeLabel = new Label("Product Code:");
    Label updateDescLabel = new Label("Product Description:");
    Label updatePriceLabel = new Label("Product Price");
    @Override
    public void start(Stage stage) {

    	
    	//Making the grid, Flynn.

    	GridPane grid = new GridPane();
        grid.setAlignment(Pos.TOP_CENTER);
        grid.setPadding(new Insets(25, 25, 25, 25));
        grid.setHgap(10);
        grid.setVgap(10);
        Scene scene = new Scene(grid, 550, 530);
        
        //setting up inputs/outputs
        HBox codeBox = new HBox(53);
        HBox descBox = new HBox(20);
        HBox priceBox = new HBox(99);
        
        codeField = new TextField();
        descriptionField = new TextField();
        priceField = new TextField();
        outputArea = new TextArea();
        outputArea.setPrefWidth(450);
        outputArea.setEditable(false);
        //output has to be a monofont or it ruins the formatting.
        outputArea.setFont(new Font("Courier New", 12));
        Label codeLabel = new Label("Enter product code:");
        Label descLabel = new Label("Enter product description:");
        Label priceLabel = new Label("Enter price:");
        
        //boxes on boxes on boxes
        codeBox.getChildren().add(codeLabel);
        codeBox.getChildren().add(codeField);
        descBox.getChildren().add(descLabel);
        descBox.getChildren().add(descriptionField);
        priceBox.getChildren().add(priceLabel);
        priceBox.getChildren().add(priceField);
        
        VBox inputBox = new VBox(10);
        
        inputBox.getChildren().add(codeBox);
        inputBox.getChildren().add(descBox);
        inputBox.getChildren().add(priceBox);
        grid.add(inputBox, 0, 0);
        

        
        grid.add(outputArea, 0 ,2);
        
        //Buttons
        addButton = new Button("Add Product");
        updateButton = new Button("Update Item");
        deleteButton = new Button("Delete Item");
        exitButton = new Button("Exit");
        
        HBox topButtons = new HBox(10);
        
        topButtons.getChildren().add(addButton);
        topButtons.getChildren().add(updateButton);
        
        topButtons.getChildren().add(deleteButton);
        topButtons.getChildren().add(exitButton);
        VBox buttonBox = new VBox(10);
        buttonBox.getChildren().add(topButtons);
        grid.add(buttonBox, 0, 3);
        
        //button events
        addButton.setOnAction(event -> addProduct());
        updateButton.setOnAction(event -> updateProduct());
        deleteButton.setOnAction(event -> deleteProduct());
        exitButton.setOnAction(event -> exitProg());
        
        stage.setScene(scene);
        displayAll();
        stage.show();
    }

    public static void main(String[] args) {
        launch();
    }
    
    public void exitProg() 
    {
    	System.exit(0);
    }
    
    public void updateProduct() 
    {
    	TextInputDialog prompt = new TextInputDialog();
    	prompt.setHeaderText("Enter product code");
    	prompt.showAndWait();
       String inputCode = prompt.getEditor().getText();
    	if(inputCode.isEmpty() ||inputCode.isBlank()) 
    	{
    		Alert close = new Alert(Alert.AlertType.CONFIRMATION);
    		close.setHeaderText("Update cancelled");
    		close.show();
    	}
    	else 
    	{
 	   	    Product product = ProductDB.get(inputCode);
 	        if (product == null) 
 	        {
 	        	v.ValidAlert("No product matches that code.", "Product not found");
 	            System.out.println("No product matches that code.\n");
 	            return;
 	        }
 	        else 
 	        {
 	        	GridPane updateGrid = new GridPane();
 	        	updateGrid.setAlignment(Pos.TOP_CENTER);
 	        	updateGrid.setPadding(new Insets(25, 25, 25, 25));
 	        	updateGrid.setHgap(10);
 	        	updateGrid.setVgap(10);

 	        	

 	            
 	            HBox updateCodeBox = new HBox(10);
 	            HBox updateDescBox = new HBox(10);
 	            HBox updatePriceBox = new HBox(10);
 	            
 	            updateCodeBox.getChildren().add(updateCodeLabel);
 	            updateCodeBox.getChildren().add(updateCodeField);
 	            
 	            updateDescBox.getChildren().add(updateDescLabel);
 	            updateDescBox.getChildren().add(updateDescField);
 	            
 	            updatePriceBox.getChildren().add(updatePriceLabel);
 	            updatePriceBox.getChildren().add(updatePriceField);
 	            
 	            VBox updateFields = new VBox(10);
 	            updateFields.getChildren().add(updateCodeBox);
 	            updateFields.getChildren().add(updateDescBox);
 	            updateFields.getChildren().add(updatePriceBox);
 	            
 	            updateGrid.add(updateFields, 0, 0);
 	            
 	            updateCodeField.setText(product.getCode());
 	            updateCodeField.setEditable(false);
 	            updateDescField.setText(product.getDescription());
 	            Double oldPrice = product.getPrice();
 	            
 	           updatePriceField.setText(oldPrice.toString());
 	            
 	           Button updateProductButton = new Button("Update Product");
 	           Button cancelButton = new Button("Cancel Update");
 	           
 	           HBox updateButtonBox = new HBox(10);
 	           updateButtonBox.getChildren().add(updateProductButton);
 	           updateButtonBox.getChildren().add(cancelButton);
 	           updateGrid.add(updateButtonBox, 0, 1);
 	           
 	           
 	           
 	            updateProductButton.setOnAction(event -> UpdateConfirm(product));
 	            cancelButton.setOnAction(event -> CancelUpdate(updateScreen));
 	        	Scene scene = new Scene(updateGrid, 400, 200);
 	            updateScreen.setScene(scene);
 	        	updateScreen.show();
 	        }
    	}
    	
    }
    public void CancelUpdate(Stage update) 
    {
    	update.hide();
    }
    public void UpdateConfirm(Product p) 
    {
    	
    	String errorMsg = "";
    	
    	errorMsg += v.isPresent(updateCodeField.getText(), "Product Code");
    	errorMsg += v.isPresent(updateDescField.getText(), "Product Description");
    	errorMsg += v.isPresent(updatePriceField.getText(), "Product Price");
    	
    	if (errorMsg.isEmpty()) 
    	{
    		
    		errorMsg += v.isDouble(updatePriceField.getText(), "Product Price");
    		
    		if(errorMsg.isEmpty()) 
    		{
            	String code = updateCodeField.getText();
            	String desc = updateDescField.getText();
            	
            	Double price = Double.parseDouble(updatePriceField.getText());
            	
            	Alert confirmation = new Alert(Alert.AlertType.CONFIRMATION);
            	confirmation.setHeaderText("Update " + p.getDescription());
            	
            	String formatString = "Update the following? \n" + "%s to %s \n" + "%s to %s \n" + "%f to %f";
            	String outputString = String.format(formatString, p.getCode(), code, p.getDescription(), desc, p.getPrice(), price);
            	confirmation.setContentText(outputString);
            	
            	confirmation.showAndWait();
            	if(confirmation.getResult() == ButtonType.OK) 
            	{
            		//if the user is sure updates the product
            		p.setCode(code);
            		p.setDescription(desc);
            		p.setPrice(price);
            		ProductDB.update(p);
            		displayAll();
            		CancelUpdate(updateScreen);
            	}
            	else if(confirmation.getResult() == ButtonType.CANCEL)
            	{
            		Alert close = new Alert(Alert.AlertType.CONFIRMATION);
            		close.setHeaderText("Update cancelled");
            		close.show();
            	}
    		}
    		else 
    		{
    			//shows if the price is invalid 
    			v.ValidAlert(errorMsg, "Invalid Data");
    		}
    	}
    	else 
    	{
    		//shows if anything is missing
    		v.ValidAlert(errorMsg, "Missing Data");
    	}

    	
    }
    
    public void displayAll() {
        //clears the output area just to be sure 
        outputArea.clear();
        //formats the output text
        String outputText = "";
        String outputFormat = "%-10s%-40s%-10s%n";
        ArrayList<Product> products = ProductDB.getAll();

        String headerformat = String.format(outputFormat, "Code", "Description", "Price");
        
        outputText += headerformat;
        outputText += "===================================================" +"\n";
        //adds all the products to the output
        for (Product p : products) {
            outputText += String.format(outputFormat, p.getCode(), p.getDescription(), p.getPriceFormatted(), null);
        }
        //sets the output area text to the list of products 
        outputArea.setText(outputText);
    }
   public void addProduct() {
	   String errorMsg = ""; 
	   //checks that all the fields exist
	   errorMsg += v.isPresent(codeField.getText(), "Product Code");
	   errorMsg += v.isPresent(descriptionField.getText(), "Product Description");
	   errorMsg += v.isPresent(priceField.getText(), "Product Price");
	   
	   if (errorMsg.isEmpty()) 
	   {
		   //checks that the price is a valid double
		   String code = codeField.getText();
		   String description = descriptionField.getText();
		   
		   errorMsg += v.isDouble(priceField.getText(), "Product Price");
		   
		   if(errorMsg.isEmpty()) 
		   {
			   double price = Double.parseDouble(priceField.getText());
		       Product product = new Product(code, description, price);
		       ProductDB.add(product);
		       //shows confirmation the product was added and then refreshes the output list
		        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
				alert.setHeaderText("Product Added");
			    alert.setContentText(description + " has been added.\n");
			    codeField.clear();
			    descriptionField.clear();
			    priceField.clear();
			    displayAll();

		   }
		   else 
		   {
			   //shows the price was invalid
			   v.ValidAlert(errorMsg, "Invalid Data");
		   }
	   }
	   else 
	   {//shows something was missing.
		   v.ValidAlert(errorMsg, "Invalid Entry");
	   }
       
    }

    public void deleteProduct() 
    {
    	//asks the user for a product code
    	TextInputDialog prompt = new TextInputDialog();
    	prompt.setHeaderText("Enter product code");
    	prompt.showAndWait();
       String inputCode = prompt.getEditor().getText();
       //if nothing is entered or the cancel button is hit.
    	if(inputCode.isEmpty() ||inputCode.isBlank()) 
    	{
    		Alert close = new Alert(Alert.AlertType.CONFIRMATION);
    		close.setHeaderText("Delete cancelled");
    		close.show();
    	}
    	else 
    	{
    		//looks up the product based on what was entered
 	   	    Product product = ProductDB.get(inputCode);
 	        if (product == null) 
 	        {
 	        	v.ValidAlert("No product matches that code.", "Product not found");
 	            return;
 	        }
 	        else 
 	        {
 	        	//confirms the user is sure they want to delete a product
 	        	Alert confirmation = new Alert(Alert.AlertType.CONFIRMATION);
            	confirmation.setHeaderText("Delete " + product.getDescription() + "?");
 	        	confirmation.showAndWait();
            	if(confirmation.getResult() == ButtonType.OK) 
            	{
     	            //shows confirmation the product was deleted and then refreshes the output list 

    		        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
    				alert.setHeaderText("Product Removed");
    			    alert.setContentText(product.getDescription() + " has been removed.\n");  
     	            ProductDB.delete(product);
     	            alert.show();
    			    displayAll();
            	}
            	else if(confirmation.getResult() == ButtonType.CANCEL)
            	{
            		//cancels the delete
            		Alert close = new Alert(Alert.AlertType.CONFIRMATION);
            		close.setHeaderText("Delete cancelled");
            		close.show();

 	        }
    	}
           
    }
}
}